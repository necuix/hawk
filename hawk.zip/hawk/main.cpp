#include "../core/logger.hpp"
#include "../gui/preloader.hpp"
#include <iostream>
#include <thread>
#include <string>
#include <chrono>

int main() {
    gui::show_preloader(100);

    if (!Logger::init()) {
        std::cerr << "Logger failed to initialize.\n";
        return 1;
    }

    std::string target;
    int port;
    std::string method;
    int duration;

    std::cout << "\nEnter Target (IPv4 or Domain): ";
    std::getline(std::cin, target);

    std::cout << "Enter Port (e.g. 443, 80, 8080): ";
    std::cin >> port;

    std::cout << "Enter Method (xrage, xcrypt, pieray): ";
    std::cin >> method;

    std::cout << "Enter Duration (Max 90s): ";
    std::cin >> duration;

    if (duration > 90 || duration < 1) {
        std::cerr << "Invalid duration. Must be between 1 and 90 seconds.\n";
        return 1;
    }

    std::jthread engine([&]() {
        gui::render_gui(target, port, method, duration);
    });

    engine.join();
    return 0;
}