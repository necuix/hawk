#pragma once
#include <string>
#include <vector>

namespace hawk {
    void start_engine(const std::string& target,
                      const std::string& method,
                      int port,
                      int duration,
                      const std::vector<std::string>& proxies);
}