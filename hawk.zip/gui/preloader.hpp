#pragma once
#include <iostream>
#include <string>
#include <thread>
#include <chrono>

namespace gui {
    inline void print_step(const std::string& label, const std::string& status, const std::string& extra = "") {
        std::cout << "⚙️  " << label;
        int space = 35 - static_cast<int>(label.length());
        for (int i = 0; i < space; ++i) std::cout << " ";
        std::cout << "[" << status << "]";
        if (!extra.empty()) std::cout << " (" << extra << ")";
        std::cout << "\n";
    }

    inline void show_preloader(int proxies_loaded = 0) {
        system("clear");
        std::cout << "\n";

        print_step("Loading Proxies...", "🟢", std::to_string(proxies_loaded));
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        print_step("Loading CLI Interface...", "🟢");
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        print_step("Initializing H.A.W.K-engine...", "🟢");
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        print_step("Booting The GUI...", "🟢");
        std::this_thread::sleep_for(std::chrono::milliseconds(700));
    }

    inline void render_gui(const std::string& target, int port, const std::string& method, int duration) {
        system("clear");
        std::cout << "\n┌─────────── H.A.W.K - High Accuracy Web Killer ───────────┐\n";
        std::cout << "│ by @necuix│Version: H1-R stable                          │\n";
        std::cout << "└──────────────────────────────────────────────────────────┘\n";

        std::cout << "\n┌──────────── H.A.W.K Methods ────────────┐\n";
        std::cout << "│ 1. xrage [L7] - HTTP/HTTPS Flood        │\n";
        std::cout << "│ 2. xcrypt [L4] - TCP Packet Flood       │\n";
        std::cout << "│ 3. pieray [L7] - TLS Handshake Flood    │\n";
        std::cout << "└─────────────────────────────────────────┘\n";

        std::cout << "\n┌─────────────── Target ───────────────┐\n";
        std::cout << "│ Target : " << target << "\n";
        std::cout << "│ Port   : " << port << "\n";
        std::cout << "│ Method : " << method << "\n";
        std::cout << "│ Duration : " << duration << "s [Max: 90s] \n";
        std::cout << "└──────────────────────────────────────┘\n";

        std::cout << "\n┌───────────── Stats ──────────────┐\n";
        std::cout << "│ Time    : 00:00 sec              │\n";
        std::cout << "│ Sent    : 0                      │\n";
        std::cout << "│ Errors  : 0                      │\n";
        std::cout << "│ RPS     : 0                      │\n";
        std::cout << "└──────────────────────────────────┘\n";
    }
}