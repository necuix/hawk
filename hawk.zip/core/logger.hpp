#pragma once
#include <iostream>
#include <fstream>
#include <string>

class Logger {
public:
    static bool init() {
        std::ofstream log("hawk/logs.txt", std::ios::app);
        if (!log.is_open()) {
            std::cerr << "[ERROR] Failed to open logs.txt\n";
            return false;
        }
        log << "[INIT] Logger initialized.\n";
        log.close();
        return true;
    }

    static void log_info(const std::string& msg) {
        std::ofstream log("hawk/logs.txt", std::ios::app);
        log << "[INFO] " << msg << "\n";
        log.close();
    }

    static void log_error(const std::string& msg) {
        std::ofstream log("hawk/logs.txt", std::ios::app);
        log << "[ERROR] " << msg << "\n";
        log.close();
    }
};