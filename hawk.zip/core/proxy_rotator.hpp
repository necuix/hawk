#pragma once
#include <vector>
#include <string>
#include <mutex>

class ProxyRotator {
public:
    ProxyRotator(const std::vector<std::string>& proxy_list)
        : proxies(proxy_list), index(0) {}

    std::string get_next() {
        std::lock_guard<std::mutex> lock(mutex);
        if (proxies.empty()) return "";

        std::string proxy = proxies[index];
        index = (index + 1) % proxies.size();
        return proxy;
    }

    bool is_empty() const {
        return proxies.empty();
    }

    size_t size() const {
        return proxies.size();
    }

private:
    std::vector<std::string> proxies;
    size_t index;
    mutable std::mutex mutex;
};