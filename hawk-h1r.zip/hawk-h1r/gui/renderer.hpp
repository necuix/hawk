#pragma once
#include <iostream>
#include <string>

namespace gui {

    inline void clear_screen() {
        std::cout << "\033[2J\033[1;1H";
    }

    inline void render_main_gui(const std::string& version,
                                 const std::string& method,
                                 const std::string& target,
                                 int port,
                                 int duration,
                                 int elapsed,
                                 int sent,
                                 int errors,
                                 int rps) {
        clear_screen();
        std::cout << "\033[1;31m";

        std::cout << "┌─────────── H.A.W.K - High Accuracy Web Killer ───────────┐\n";
        std::cout << "│ by @necuix│Version: " << version << " \n";
        std::cout << "└─────────────────────────────────────────────────┘\n\n";

        std::cout << "┌──────────── H.A.W.K Methods ────────────┐\n";
        std::cout << "│ 1. xrage [L7] - HTTP/HTTPS Flood         │\n";
        std::cout << "│ 2. xcrypt [L4] - TCP Packet Flood        │\n";
        std::cout << "│ 3. pieray [L7] - TLS Handshake Flood     │\n";
        std::cout << "└──────────────────────────────────────────┘\n\n";

        std::cout << "┌─────────────── Target ───────────────┐\n";
        std::cout << "│ Target  : " << target << "\n";
        std::cout << "│ Port    : " << port << "\n";
        std::cout << "│ Method  : " << method << "\n";
        std::cout << "│ Duration: " << duration << "s [Max: 90s]\n";
        std::cout << "└─────────────────────────────────────────┘\n\n";

        std::cout << "┌───────────── Stats ──────────────┐\n";
        std::cout << "│ Time   : " << (elapsed < 10 ? "0" : "") << elapsed << " sec\n";
        std::cout << "│ Sent   : " << sent << "\n";
        std::cout << "│ Errors : " << errors << "\n";
        std::cout << "│ RPS    : " << rps << "\n";
        std::cout << "└───────────────────────────────────────┘\n";

        std::cout << "\033[0m";
    }

}