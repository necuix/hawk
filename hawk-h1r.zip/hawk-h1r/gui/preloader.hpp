#pragma once
#include <iostream>
#include <thread>
#include <chrono>

namespace gui {

    inline void print_step(const std::string& label, const std::string& status, const std::string& extra = "") {
        std::cout << "\033[1;31m⚙️  " << label;
        if (!extra.empty()) std::cout << " " << extra;
        std::cout << "...\t[🟢] " << status << "\033[0m" << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }

    inline void show_preloader(int proxy_count) {
        system("clear"); // optional: clear screen
        print_step("Loading Proxies", "", "(" + std::to_string(proxy_count) + ")");
        print_step("Loading CLI Interface");
        print_step("Initializing H.A.W.K-engine");
        print_step("Booting The GUI");
        std::this_thread::sleep_for(std::chrono::milliseconds(600));
    }

}