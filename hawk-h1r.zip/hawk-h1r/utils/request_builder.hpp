#pragma once
#include <string>
#include <vector>
#include <cstdlib>

namespace request {

    inline std::string get_random_user_agent() {
        static const std::vector<std::string> user_agents = {
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:93.0) Gecko/20100101 Firefox/93.0",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
        };
        return user_agents[rand() % user_agents.size()];
    }

    inline std::string get_random_referer(const std::string& target) {
        static const std::vector<std::string> referers = {
            "https://www.google.com/search?q=",
            "https://www.bing.com/search?q=",
            "https://duckduckgo.com/?q=",
            "https://search.yahoo.com/search?p=",
            "https://www.ecosia.org/search?q="
        };
        std::string term = target.substr(0, target.find('.'));
        return referers[rand() % referers.size()] + term;
    }

    inline std::string get_full_url(const std::string& host, int port) {
        return "http://" + host + ":" + std::to_string(port) + "/?" + std::to_string(rand());
    }

}