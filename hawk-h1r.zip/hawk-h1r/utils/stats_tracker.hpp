#pragma once
#include <atomic>
#include <chrono>

class StatsTracker {
public:
    StatsTracker() {
        reset();
    }

    void reset() {
        sent.store(0);
        errors.store(0);
        start_time = std::chrono::steady_clock::now();
    }

    void increment_sent() {
        sent.fetch_add(1, std::memory_order_relaxed);
    }

    void increment_error() {
        errors.fetch_add(1, std::memory_order_relaxed);
    }

    int get_sent() const {
        return sent.load(std::memory_order_relaxed);
    }

    int get_errors() const {
        return errors.load(std::memory_order_relaxed);
    }

    int get_elapsed_seconds() const {
        auto now = std::chrono::steady_clock::now();
        return std::chrono::duration_cast<std::chrono::seconds>(now - start_time).count();
    }

    int get_rps() const {
        int elapsed = get_elapsed_seconds();
        return (elapsed > 0) ? (get_sent() / elapsed) : 0;
    }

private:
    std::atomic<int> sent;
    std::atomic<int> errors;
    std::chrono::steady_clock::time_point start_time;
};