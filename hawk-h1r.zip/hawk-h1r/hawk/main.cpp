#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <thread>
#include <regex>

#include "core/logger.hpp"
#include "gui/preloader.hpp"
#include "hawk.hpp"

std::vector<std::string> load_proxies(const std::string& path) {
    std::vector<std::string> proxies;
    std::ifstream file(path);
    std::string line;
    while (std::getline(file, line)) {
        if (!line.empty()) {
            proxies.push_back(line);
        }
    }
    return proxies;
}

bool is_valid_ip(const std::string& ip) {
    std::regex ipv4_pattern(R"(^(\d{1,3}\.){3}\d{1,3}$)");
    return std::regex_match(ip, ipv4_pattern);
}

bool is_valid_domain(const std::string& domain) {
    std::regex domain_pattern(R"(^([a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,}$)");
    return std::regex_match(domain, domain_pattern);
}

int main() {
    Logger::init();

    std::string target;
    std::string method;
    int port;
    int duration;

    std::cout << "Target: ";
    std::getline(std::cin, target);

    if (!is_valid_ip(target) && !is_valid_domain(target)) {
        std::cout << "Invalid target.\n";
        return 1;
    }

    std::cout << "Port: ";
    std::cin >> port;
    if (port < 1 || port > 65535) {
        std::cout << "Invalid port.\n";
        return 1;
    }
    std::cin.ignore();

    std::cout << "Method: ";
    std::getline(std::cin, method);
    if (method != "xrage" && method != "xcrypt" && method != "pieray") {
        std::cout << "Invalid method.\n";
        return 1;
    }

    std::cout << "Duration: ";
    std::cin >> duration;
    if (duration < 1 || duration > 90) {
        std::cout << "Invalid duration.\n";
        return 1;
    }

    auto proxies = load_proxies("proxies.txt");

    gui::show_preloader(proxies.size());

    std::jthread engine([&]() {
        hawk::start_engine(target, method, port, duration, proxies);
    });

    engine.join();
    return 0;
}