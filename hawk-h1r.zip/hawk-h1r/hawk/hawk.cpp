#include "hawk.hpp"
#include "core/logger.hpp"
#include "gui/renderer.hpp"

#include <iostream>
#include <chrono>
#include <thread>

namespace hawk {

    void start_engine(const std::string& target,
                      const std::string& method,
                      int port,
                      int duration,
                      const std::vector<std::string>& proxies) {
        
        spdlog::info("Engine started with method={}, target={}, port={}, duration={}",
                     method, target, port, duration);

        int elapsed = 0;
        int rps = 297200;
        int sent = 0;
        int errors = 0;

        while (elapsed < duration) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            elapsed++;
            sent += rps;
            if (elapsed % 9 == 0) errors++;

            gui::render_main_gui("H1-R stable", method, target, port, duration,
                                 elapsed, sent, errors, rps);
        }

        spdlog::info("Engine finished. Total Sent={}, Errors={}, Duration={}s",
                     sent, errors, duration);
    }

}