#pragma once
#include <memory>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>

class Logger {
public:
    static void init() {
        try {
            auto file_logger = spdlog::basic_logger_mt("hawk", "logs.txt", true);
            file_logger->set_pattern("[%Y-%m-%d %H:%M:%S] [%^%l%$] %v");
            file_logger->set_level(spdlog::level::info);
            spdlog::set_default_logger(file_logger);
        } catch (const spdlog::spdlog_ex& ex) {
            std::cerr << "Logger initialization failed: " << ex.what() << std::endl;
        }
    }
};